// =====================================================================
// VESTA AI — Cloud Functions proxy
// Tujuan: menyembunyikan API key SumoPod AI & Tavily dari client.
// Client (app.js) memanggil fungsi ini lewat httpsCallable(); fungsi ini
// yang menyimpan & memakai key rahasia di sisi server (Secret Manager).
//
// Cara set secret (jalankan sekali dari terminal, lihat README.md):
//   firebase functions:secrets:set SUMOPOD_API_KEY
//   firebase functions:secrets:set TAVILY_API_KEY
// =====================================================================

const { onCall, HttpsError } = require("firebase-functions/v2/https");
const { defineSecret } = require("firebase-functions/params");
const { setGlobalOptions } = require("firebase-functions/v2");

setGlobalOptions({ region: "asia-southeast2", maxInstances: 10 });

const SUMOPOD_API_KEY = defineSecret("SUMOPOD_API_KEY");
const TAVILY_API_KEY = defineSecret("TAVILY_API_KEY");

const SUMOPOD_BASE_URL = "https://ai.sumopod.com/v1";
const TAVILY_BASE_URL = "https://api.tavily.com/search";
const MODEL = "gpt-4o-mini";
const MAX_TOKENS = 4096;
const TEMPERATURE = 0.7;

// ---------------------------------------------------------------------
// chatCompletion — proxy ke SumoPod AI (OpenAI-compatible)
// ---------------------------------------------------------------------
exports.chatCompletion = onCall(
  { secrets: [SUMOPOD_API_KEY], cors: true, timeoutSeconds: 60 },
  async (request) => {
    if (!request.auth){
      throw new HttpsError("unauthenticated", "Kamu harus login terlebih dahulu.");
    }
    const messages = request.data?.messages;
    if (!Array.isArray(messages) || messages.length === 0){
      throw new HttpsError("invalid-argument", "Parameter 'messages' wajib berupa array dan tidak boleh kosong.");
    }
    // Batasi payload agar tidak disalahgunakan
    if (messages.length > 25){
      throw new HttpsError("invalid-argument", "Riwayat pesan terlalu panjang.");
    }

    try{
      const response = await fetch(`${SUMOPOD_BASE_URL}/chat/completions`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${SUMOPOD_API_KEY.value()}`
        },
        body: JSON.stringify({
          model: MODEL,
          max_tokens: MAX_TOKENS,
          temperature: TEMPERATURE,
          messages
        })
      });

      if (!response.ok){
        const errBody = await response.text();
        console.error("SumoPod error:", response.status, errBody);
        throw new HttpsError("internal", `SumoPod AI mengembalikan error (${response.status}).`);
      }

      const data = await response.json();
      const text = data?.choices?.[0]?.message?.content || "";
      return { text };
    }catch(err){
      if (err instanceof HttpsError) throw err;
      console.error("chatCompletion error:", err);
      throw new HttpsError("internal", "Gagal menghubungi layanan AI. Coba lagi sebentar lagi.");
    }
  }
);

// ---------------------------------------------------------------------
// webSearch — proxy ke Tavily Search API
// ---------------------------------------------------------------------
exports.webSearch = onCall(
  { secrets: [TAVILY_API_KEY], cors: true, timeoutSeconds: 30 },
  async (request) => {
    if (!request.auth){
      throw new HttpsError("unauthenticated", "Kamu harus login terlebih dahulu.");
    }
    const searchQuery = (request.data?.query || "").trim();
    if (!searchQuery){
      throw new HttpsError("invalid-argument", "Parameter 'query' wajib diisi.");
    }

    try{
      const response = await fetch(TAVILY_BASE_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          api_key: TAVILY_API_KEY.value(),
          query: searchQuery,
          search_depth: "basic",
          max_results: 5,
          include_answer: false
        })
      });

      if (!response.ok){
        const errBody = await response.text();
        console.error("Tavily error:", response.status, errBody);
        throw new HttpsError("internal", `Tavily mengembalikan error (${response.status}).`);
      }

      const data = await response.json();
      const results = (data.results || []).map((r) => ({
        title: r.title,
        url: r.url,
        content: (r.content || "").slice(0, 600)
      }));
      return { results };
    }catch(err){
      if (err instanceof HttpsError) throw err;
      console.error("webSearch error:", err);
      throw new HttpsError("internal", "Gagal melakukan pencarian web. Coba lagi sebentar lagi.");
    }
  }
);
