# Vesta AI ("Web Ahay") — Panduan Setup & Deploy

Chatbot AI premium: statis di **GitHub Pages** (domain `raflymusyaf.web.id` via Cloudflare
DNS), dengan **Firebase** untuk Auth + Firestore, dan **Firebase Cloud Functions** sebagai
proxy rahasia ke SumoPod AI & Tavily.

## ⚠️ Kenapa ada Cloud Functions, padahal katanya "statis"?

GitHub Pages hanya bisa menyajikan file statis (HTML/CSS/JS) — **tidak ada server** yang bisa
menyembunyikan rahasia. Kalau API key SumoPod/Tavily ditaruh langsung di `app.js`, siapa pun
tinggal buka DevTools → tab Network/Sources dan key-nya kelihatan & bisa dicuri/disalahgunakan,
berapa pun cepatnya kamu "menyamarkannya" di kode.

Solusinya: key tersebut **hanya disimpan di server** (Firebase Cloud Functions, project yang
sama dengan yang kamu pakai untuk Auth/Firestore). Browser tidak pernah menyentuhnya — browser
cuma memanggil fungsi `chatCompletion` / `webSearch` yang sudah login, lalu fungsi itu yang
meneruskan permintaan ke SumoPod/Tavily di sisi server. Ini satu-satunya cara aman untuk arsitektur
"hosting statis + AI API key rahasia".

Konfigurasi `FIREBASE_CONFIG` di `app.js` **bukan rahasia** — itu memang didesain publik oleh
Firebase (dipakai untuk mengenali project mana yang dituju), keamanannya datang dari Firestore
Security Rules (`firestore.rules`) dan App Check/Auth, bukan dari menyembunyikan config itu.

## 📁 Struktur folder

```
webahay/
├── public/              ← ini yang di-push ke GitHub Pages
│   ├── index.html
│   ├── style.css
│   └── app.js
├── functions/           ← Cloud Functions (proxy API key)
│   ├── index.js
│   └── package.json
├── firestore.rules
├── firestore.indexes.json
└── firebase.json
```

## 🚀 Langkah setup

### 1. Siapkan Firebase CLI
```bash
npm install -g firebase-tools
firebase login
cd webahay
firebase use wa-clone-rafly
```

### 2. Aktifkan Google Sign-In
Firebase Console → project **wa-clone-rafly** → Authentication → Sign-in method →
aktifkan **Google**.

### 3. Buat Firestore Database
Firebase Console → Firestore Database → Create database → mode **Native**, region terdekat
(mis. `asia-southeast2`).

### 4. Simpan API key sebagai Secret (bukan hardcoded!)
```bash
firebase functions:secrets:set SUMOPOD_API_KEY
# masukkan: sk-QTrGoAspLLuYSacIKQyuww

firebase functions:secrets:set TAVILY_API_KEY
# masukkan: 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
```
Key ini akan disimpan terenkripsi di Google Secret Manager, dan hanya bisa diakses oleh fungsi
yang secara eksplisit memintanya (lihat `defineSecret` di `functions/index.js`).

### 5. Deploy Firestore rules & Cloud Functions
```bash
cd functions && npm install && cd ..
firebase deploy --only firestore:rules,firestore:indexes,functions
```
Setelah ini, dua endpoint callable akan aktif: `chatCompletion` dan `webSearch`.

### 6. Push folder `public/` ke GitHub Pages
Di repo GitHub kamu (mis. `raflymusyaf/webahay`):
```bash
cp -r public/* /path/ke/repo/
cd /path/ke/repo
echo "raflymusyaf.web.id" > CNAME
git add . && git commit -m "Deploy Vesta AI" && git push
```
Lalu di Settings → Pages, pastikan source-nya branch yang berisi file tadi.

### 7. Cloudflare DNS
Tambahkan record berikut di zona `raflymusyaf.web.id` (proxy status: **DNS only**, bukan
proxied, agar GitHub Pages bisa menerbitkan sertifikat SSL-nya):
```
Type   Name    Value
A      @       185.199.108.153
A      @       185.199.109.153
A      @       185.199.110.153
A      @       185.199.111.153
CNAME  www     raflymusyaf.github.io
```
Setelah propagasi, aktifkan "Enforce HTTPS" di GitHub Pages settings.

### 8. Aset logo
Pastikan dua file berikut sudah bisa diakses publik (dipakai langsung sebagai `<img src>` /
favicon di `index.html`, bukan sebagai SVG inline):
- `https://raflymusyaf.web.id/logoweb.png` → favicon / hasil pencarian Google
- `https://raflymusyaf.web.id/logodash.png` → logo di dalam tampilan aplikasi

## 🧠 Alur onboarding username (sudah dioptimalkan)

Sebelumnya, layar "buat username" terpisah membuat proses login terasa lambat. Sekarang:
begitu pengguna berhasil login dengan Google, sistem langsung membuatkan **username otomatis**
dari nama akun Google mereka (disaring huruf kecil+angka, ditambah suku kata acak bila perlu
untuk menjaga keunikan) dan langsung menyimpan profil — tanpa layar blocking. Pengguna tetap
bisa mengganti username kapan saja dengan mengklik nama mereka di pojok kiri bawah sidebar.

## 🔐 Ringkasan keamanan yang diterapkan

- Semua panggilan ke SumoPod AI & Tavily lewat Cloud Functions (`request.auth` wajib ada).
- Firestore Security Rules membatasi setiap pengguna hanya bisa membaca/menulis sesi chat
  miliknya sendiri (dicocokkan lewat `uniqueLinkId`), sementara `shared_chats` bisa dibaca
  publik (read-only) tapi hanya bisa dibuat oleh pengguna yang login.
- Semua teks dari pengguna di-escape (`escapeHtml`) sebelum dirender ke DOM untuk mencegah XSS;
  tautan di dalam pesan diproses lewat regex setelah escaping, bukan sebelum.
- Validasi tipe & ukuran file dilakukan di client (foto ≤10MB, dokumen ≤5MB) dan panjang riwayat
  pesan dibatasi di server (maks 25 pesan per request) sebagai lapisan tambahan.
